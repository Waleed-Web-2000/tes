<?php 
	$con = mysqli_connect('localhost','u453504845_lj','selfmadeu12@@AA');
	mysqli_select_db($con, 'u453504845_lj');

 ?>